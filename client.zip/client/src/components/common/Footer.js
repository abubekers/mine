const Footer = () => {
	const link = "http://myportofolio.yenetask.com/";
	const target = "_blank";

	return (
		<div className="container">
			Copyright © <small>{new Date().getFullYear()}</small> Abubeker Ahmed Full Stack developer{" "}
			<a href={link} target={target}>
				Personal website
			</a>
		</div>
	);
};

export default Footer;
