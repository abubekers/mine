import React from "react";

function Home() {
	const link = "http://myportofolio.yenetask.com/";
	const target = "_blank";

	return (
		<div className="container">
			<h1>Excelerent Slolution Assignment</h1>
			<p>
				<b>Deverloper</b>:Abubeker Ahmed
				<p>
					<a href={link} target={target}>
						Personal Website
					</a>
				</p>
			</p>
		</div>
	);
}

export default Home;
